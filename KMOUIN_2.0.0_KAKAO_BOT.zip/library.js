const rp = require('request-promise');

const option = {
    uri: `http://203.255.215.220/webseat/domian5.asp`
}

const data = function() {
    return new Promise(async (resolve, reject) => {
        const now = await rp(option)
        .then((result) => {
            const temp = result.split('/');
            let seats = [];
            let show = [];
            const check =  /<FONT SIZE=-1>&nbsp;/;
            temp.forEach(element => {
               if(check.test(element)) {
                   seats.push(element + '+');
               }
            });
            for(let i = 1; i <= 8; i += 2) {
                const start1 = seats[i - 1].indexOf(';') + 1;
                const stop1 = seats[i - 1].indexOf('+') - 2;
                const start2 = seats[i].indexOf(';') + 1;
                const stop2 = seats[i].indexOf('+') - 2;

                const all = Number(seats[i - 1].substring(start1, stop1 + 1));
                const use = Number(seats[i].substring(start2, stop2 + 1));
                const empty = all - use;
                const percentage = (use / all * 100).toFixed(2);
                show.push(`제 ${parseInt(i / 2) + 1}열람실 : 전체 좌석 ${all}석, 사용 좌석 ${use}석, 빈 좌석 ${empty}석, 사용률 ${percentage}％\n`);
            }
            return show;
        })
        .catch((err) => {
            throw err;
        });

        resolve(now);
    });
}

data();

exports.data = data;
