const express = require('express');
const library = require('./library.js');
const http = require('http');

const app = express();
const router = express.Router();

app.use('/', router);

router.route('/library').post(async (req, res) => {
    let temp = '1분에 한번씩 업데이트 됩니다. \n';
    await library.data().then((result) => {
        result.forEach(element => {
            temp = temp + element;
        });
    });
    const responseBody = await {
        version: "2.0",
        template: {
          outputs: [
            {
              simpleText: {
                text: temp
              }
            }
          ],
          quickReplies: [
            {
              messageText: "🏠처음으로",
              action: "message",
              label: '🏠처음으로'
            }
          ]
        }
      };
    await res.status(200).send(responseBody);
    await res.end();
});

http.createServer(app).listen(process.env.PORT || 8080, () => {
    console.log('8080번');
})
