const express = require('express');
const weather = require('./weather.js');
const http = require('http');

const app = express();
const router = express.Router();

app.use('/', router);

router.route('/weather').get(async (req, res) => {
    let temp = '';
    await weather.data().then((result) => {
        for(let i = 0; i < result.length; i++) {
            if(i == 0) {
                temp = '기온 : ' + result[i].기온 + '\n';
                temp = temp + '풍속 : ' + result[i].풍속 + '\n';
                temp = temp + '습도 : ' + result[i].습도 + '\n';
                temp = temp + '강수량 : ' + result[i].강수량 +'\n';
            }
            else {
                temp = temp + '강수확률 : ' + result[i].강수확률;
            }
        }
    });
    await res.status(200).send(temp);
    await res.end();
});

http.createServer(app).listen(8080, () => {
    console.log('8080번');
})
