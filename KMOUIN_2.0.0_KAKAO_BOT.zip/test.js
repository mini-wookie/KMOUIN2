const crawling = require('./crawling.js');

crawling.crawling_data('http://www.kmou.ac.kr/coop/dv/dietView/selectDietDateView.do?mi=1189').then((result) => {
    console.log(result);
})
