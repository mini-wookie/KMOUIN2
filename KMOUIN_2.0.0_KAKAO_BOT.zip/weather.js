const rp = require('request-promise');

//초단기실황 base_date, 동네예보 base_date
const year = String(new Date().getFullYear());
let month = String(new Date().getMonth() + 1);
if(month.length == 1) {
    month = '0' + month;
}
const date = String(new Date().getDate());
const base_date = year + month + date;

//초단기 실황 base_time, 동네예보 base_time
let hour = String(new Date().getHours());
if(hour.length == 1) {
    hour = '0' + hour;
}

let minute = String(new Date().getMinutes());
if(minute.length == 1) {
    minute = '0' + minute;
}

const base_time1 = hour + minute;
let  base_time2;

if(hour === '03' || hour === '04') {
    base_time2 = '0210';
}
else if(hour === '06' || hour === '07') {
    base_time2 = '0510';
}
else if(hour === '09' || hour === '10') {
    base_time2 = '0810';
}
else if(hour === '15' || hour === '16') {
    base_time2 = '1410';
}
else if(hour === '18' || hour === '19') {
    base_time2 = '1710';
}
else if(hour === '21' || hour === '22') {
    base_time2 = '2010';
}
else if(hour === '00' || hour === '01') {
    base_time2 = '2310';
}
else if(hour === '02') {
    if('00' <= minute <= '09') {
        base_time2 = '2310';
    }
    else {
        base_time = '0210';
    }
}
else if(hour === '05') {
    if('00' <= minute <= '09') {
        base_time2 = '0210';
    }
    else {
        base_time = '0510';
    }
}
else if(hour === '08') {
    if('00' <= minute <= '09') {
        base_time2 = '0510';
    }
    else {
        base_time = '0810';
    }
}
else if(hour === '11') {
    if('00' <= minute <= '09') {
        base_time2 = '0810';
    }
    else {
        base_time = '1110';
    }
}
else if(hour === '14') {
    if('00' <= minute <= '09') {
        base_time2 = '1110';
    }
    else {
        base_time = '1410';
    }
}
else if(hour === '17') {
    if('00' <= minute <= '09') {
        base_time2 = '1410';
    }
    else {
        base_time = '1710';
    }
}
else if(hour === '20') {
    if('00' <= minute <= '09') {
        base_time2 = '1710';
    }
    else {
        base_time = '2010';
    }
}
else if(hour === '23') {
    if('00' <= minute <= '09') {
        base_time2 = '2010';
    }
    else {
        base_time = '2310';
    }
}
//초단기실황
const option1 = {
    uri: `http://apis.data.go.kr/1360000/VilageFcstInfoService/getUltraSrtNcst?serviceKey=VK%2BE2S5fZNd43MoNroc4mVmjAoun2ofpS83JFnjaQ5jN6roBtCe8dSOP5I8HZl6yeh4Qmua3tqOG005vvtBO1g%3D%3D&numOfRows=10&DataType=JSON&pageNo=1&base_date=${base_date}&base_time=${base_time1}&nx=98&ny=73`,
}

//동네예보
const option2 = {
    uri: `http://apis.data.go.kr/1360000/VilageFcstInfoService/getVilageFcst?serviceKey=VK%2BE2S5fZNd43MoNroc4mVmjAoun2ofpS83JFnjaQ5jN6roBtCe8dSOP5I8HZl6yeh4Qmua3tqOG005vvtBO1g%3D%3D&numOfRows=8&DataType=JSON&pageNo=1&base_date=20200318&base_time=1000&nx=98&ny=73`
}

const data = function() {
    return new Promise(async (resolve, reject) => {
        const now = await rp(option1)
        .then((result) => {
            let weather = {};
            console.log('초단기 실행');
            let data = JSON.parse(result);
            weather = {
                "기온" : String(data.response.body.items.item[3].obsrValue) + '℃',
                "풍속" : String(data.response.body.items.item[7].obsrValue) + '㎧',
                "습도" : String(data.response.body.items.item[1].obsrValue) + '％',
                "강수량" : String(data.response.body.items.item[2].obsrValue) + '㎜',
            }
            console.log(weather);
            return weather;
        })
        .catch((err) => {
            throw err;
        });

        const forecast = await rp(option2)
        .then((result) => {
            let weather = {};
            console.log('동네예보 실행');
            let data = JSON.parse(result);
            weather = {
                "강수확률" : String(data.response.body.items.item[0].fcstValue)
            }
            console.log(weather);
            return weather;
        })
        .catch((err) => {
            throw err;
        });

        resolve([now, forecast]);
    });
}

data();

// exports.data = data;
